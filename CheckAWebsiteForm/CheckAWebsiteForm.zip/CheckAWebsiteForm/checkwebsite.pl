use LWP::UserAgent;
use Getopt::Long;
use JSON;

my $website='';
my %output;

GetOptions("website=s" => \$website);


my $ua = LWP::UserAgent->new;
$ua->timeout(10);



        my $response = $ua->head($website);

        if ($response->is_success) {
            
			$output{'status'} = "OK";
        }
        else {
           $output{'status'} = "BAD"; 
        }




my $json = encode_json(\%output);
print $json;


