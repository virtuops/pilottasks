#
#
#  Writes data to a file for later use, one line at a time.
#
#

use strict;
use warnings;
use JSON;
use Getopt::Long;

my ($filename, $arrayname, $recordseparator, $fieldnames, $fieldseparator, $searchstring);
my %output;

GetOptions(
        "filename=s" => \$filename,
        "arrayname:s" => \$arrayname,
        "recordseparator:s" => \$recordseparator,
        "fieldseparator:s" => \$fieldseparator,
        "fieldnames:s" => \$fieldnames,
        "searchstring:s" => \$searchstring
        );

open (READDATA,"$filename") || die "{\"status\":\"Cannot open ".$filename."\"}\n";

my @data;
my @fieldnames = split(',',$fieldnames);
my $search = qr/$searchstring/;
my $count = 0;

while (<READDATA>) {
        chomp $_;
# 3645,"Detroit Metropolitan Wayne County Airport","Detroit","United States","DTW","KDTW",42.212398529052734,-83.35340118408203,645,-5,"A","America/New_York","airport","OurAirports"

        if ($_ =~ /$search/i) {
                my %record;
                my @recorddata = split("$fieldseparator",$_);
                my $x = 0;
                foreach my $field (@fieldnames) {
                        $record{$field} = $recorddata[$x];
                        $x++;
                }
                push(@data,\%record);
                $count++;
        }
}

my $meta = $arrayname."_meta";
$output{"$arrayname"} = \@data;
$output{$meta}{'status'} = 'saved';
$output{$meta}{'count'} = $count;

my $json = encode_json(\%output);
print $json;
close (READDATA);
