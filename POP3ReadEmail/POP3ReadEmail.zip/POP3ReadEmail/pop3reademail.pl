#
#
# NOC HERO™ POP3 Email reader
#
# Mail::POP3Client
# IO::Socket::SSL
#
# This form task will read your POP3 email account and parse out lines from the most recently matched email that you can use for other purposes.
#
# It is rare that this task will be used in an attended fashion.  It is more likely that this will be used
# for end to end automations.
#
# This task takes in several arguments:
#
# username = a user that has an account established on a POP3 server somewhere.
# password = password for the POP3 user
# server = the server IP or FQDN for the POP3 server
# port = Port number for the POP3 server
# tlsssl = 1 or 0, dictates the use of TLS/SSL for encryption
# subjectregex = Text to match a subject
# bodyregex = Provides a match for the body


use Mail::POP3Client;
use IO::Socket::SSL;
use JSON;
use Getopt::Long;
use strict;
use warnings;

my $user = '';
my $password = '';
my @head;
my @body;
my @rows;

my $server = '';
my $port = '';
my $tlsssl = 'false';
my $subjectregex;
my $bodyregex;
my $dateregex;

#
# %output will hold the form values
#
my %output;
GetOptions("user=s" => \$user,
           "password=s" => \$password,
           "server=s" => \$server,
           "port=i" => \$port,
           "tlsssl=s" => \$tlsssl,
           "subjectregex=s" => \$subjectregex,
           "bodyregex=s" => \$bodyregex);

if (! $subjectregex) {
$subjectregex = '';
}
if (! $bodyregex) {
$bodyregex = '';
}

my $pop = Mail::POP3Client->new(USER=> $user,
PASSWORD => $password,
HOST => $server,
PORT => $port,
USESSL => $tlsssl,
DEBUG => 0,) or die("ERROR: Unable to connect to mail server.\n");

my $count = $pop->Count();
my $status = '';

if ($count < 1)
{
$status = "No email yet.";

} else {

        for (my $i=0; $i<=$count; $i++) {
                my @head = $pop->Head($i);
                my @body = $pop->Body($i);

                foreach my $header (@head) {
                    if ($header =~ qr/$subjectregex/) {
                        # you have the right email
                        foreach my $body (@body) {
                                if ($body =~ qr/$bodyregex/) {
                                                $status = $1;
                                }
                        }
                     }
                }

        }
}

if (length($status) == 0) {
        $output{'status'} = "No matches";
} else {
        $output{'status'} = $status;
}

$pop->Close();

my $json = encode_json(\%output);
print $json;

