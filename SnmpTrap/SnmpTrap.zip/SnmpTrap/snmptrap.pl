#
# Send Trap Utility
#
use strict;
use warnings;
use Net::SNMP;
use Getopt::Long;
use JSON;

my %output;
my ($status,$number,$destination,$interval,$community,$generic,$specific,$oid,$agentaddr,$port,$string);

GetOptions(
                "destination=s" => \$destination,
                "generic=s" => \$generic,
                "number=s" => \$number,
                "interval=s" => \$interval,
                "agentaddr=s" => \$agentaddr,
                "specific=s" => \$specific,
                "oid=s" => \$oid,
                "port=s" => \$port,
                "community=s" => \$community,
                "string=s" => \$string
        );





my $session = Net::SNMP->session(
  -hostname    => $destination,
  -community   => $community,
# -nonblocking => 1,
  -timeout     => 1,
  -retries     => 1,
  -port        => $port,
);


my $counter = 0;
while (1) {

  $session->trap(
     -enterprise   => $oid,
     -agentaddr => $agentaddr,
    -generictrap  => $generic,
    -specifictrap => $specific,
    -varbindlist  => [$oid.1, OCTET_STRING, $string . " ($counter)"],
  ) or die "error: $!";

  $counter++;
  last if ($counter > $number);
}

$output{'status'} = $counter;
my $json=encode_json(\%output);
print $json
