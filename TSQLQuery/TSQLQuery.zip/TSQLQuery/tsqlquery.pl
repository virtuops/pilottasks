#
#
# Using a SQL query as input, this action needs to output a single row of data that will be stored in "output".
# TSQL Version
#

use strict;
use warnings;
use JSON;
use Getopt::Long;

my %output;
my ($status,$user,$password,$fields,$tssqllocation,$server,$query,$queryoutput,$database);

GetOptions(
                "user=s" => \$user,
                "password=s" => \$password,
				"tsqllocation=s" => \$tsqllocation,
                "database=s" => \$database,
                "server=s" => \$server,
                "query=s" => \$query,
                "fields=s" => \$fields,
                "queryoutput=s" => \$queryoutput
        );

open (FILEDATA,"+> $queryoutput") || die "Cannot open file.";

my $sql = "/bin/echo -e $query";

my $tsql = "$tsqllocation -S $server -U $user -P '$password' -D $database -o 'fhq'";

my $qcmd = "$sql | $tsql";
my @qexec = `$qcmd`;

my @fields = split(',',$fields);
my @data;

foreach my $qrow (@qexec) {
        chomp $qrow;
        my %row;
        my @f = split(/\t/, $qrow);
        my $fcount = 0;
        foreach my $field (@fields) {
        $row{$field} = $f[$fcount];
        $fcount++;
        }
        push (@data, \%row);
}

if ($#data == 0) {
        $output{'status'} = "No rows returned, may be a problem with $sql or with $tsql or with $qcmd";
} else {
        $output{'status'} = "$#data rows returned";
}

my $data = encode_json(\@data);
print FILEDATA ($data);

my $json = encode_json(\%output);
print $json;
close (FILEDATA);
