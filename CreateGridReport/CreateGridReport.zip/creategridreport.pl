#
# Creates a grid report in html using JSON data in a file.
#

use strict;
use warnings;
use JSON;
use Getopt::Long;
use Data::Dumper;

my %output;

my ($status,$header,$arrayprop,$columnnames,$columntypes,$columnheaders,$columnsizes,$datafile);

GetOptions(
        "datafile=s" => \$datafile,
        "columnnames=s" => \$columnnames,
        "columntypes:s" => \$columntypes,
        "arrayprop:s" => \$arrayprop,
        "header:s" => \$header,
        "columnheaders:s" => \$columnheaders,
        "columnsizes:s" => \$columnsizes
        );



my $weburl;
my $pilotpath;
my $timestamp = time();
my @columnnames = split(/\,/,$columnnames);
my @columntypes = ();
my @columnheaders = ();
my @columnsizes = ();
if (defined($columntypes)) {
@columntypes = split(/\,/,$columntypes);
}
if (defined($columnheaders)) {
@columnheaders = split(/\,/,$columnheaders);
}
if (defined($columnsizes)){
@columnsizes = split(/\,/,$columnsizes);
}
if (!defined($header)){
	$header = 'On Demand Report';
}
my $count = 0;
my $recid = 0;
my $records;
my @columns = ();

# process datafile
open (my $in,"<",$datafile);
local $/;
my $json_records = <$in>;
my $jrecords = decode_json($json_records);

if (!defined($arrayprop)) {
     my @currecords = @{$jrecords};
     my @gridrecords;
     my $reccount = 1;
     foreach my $rec (@currecords) {
	my %rec = %$rec;
	$rec{'recid'} = $reccount;
        $reccount++;
	push (@gridrecords, \%rec);
     }
     $records = encode_json(\@gridrecords);
} else {
    my @props = split(/\./,$arrayprop);
    my @gridrecords;
    my $reccount = 1;
    my $newcontent;
    my $propcount = 0;
    foreach my $prop (@props) {
        if ($propcount == 0) {
        $newcontent = $jrecords->{$prop};
        } else {
        $newcontent = $newcontent->{$prop};
        }
        $propcount++;
    }

    my @currecords = @{$newcontent};
        foreach my $rec (@currecords) {
        my %rec = %$rec;
        $rec{'recid'} = $reccount;
        $reccount++;
        push (@gridrecords, \%rec);
    }
    $records = encode_json(\@gridrecords);

}



# add ID row
my %idrow;
$idrow{'field'} = 'recid';
push (@columns,\%idrow);

foreach my $col (@columnnames) {
        my %colrow;
        $colrow{'field'} = $col;
        $colrow{'sortable'} = 'true';
        push (@columns,\%colrow);
}


foreach my $cols (@columns) {

	if ($cols->{'field'} eq 'recid') {
		$cols->{'caption'} = 'RECID';
		$cols->{'type'} = 'int';
		$cols->{'size'} = '35px';
		$cols->{'hidden'} = 'true';
		$count--;
	} else {
		if (defined($columnheaders[$count])){
		$cols->{'caption'} = $columnheaders[$count];
		} else {
		$cols->{'caption'} = $columnnames[$count];
		}

		if (defined($columnsizes[$count])){
		$cols->{'size'} = $columnsizes[$count];
		} else {
		$cols->{'size'} = '140px';
		}

		if (defined($columntypes[$count])){
		$cols->{'type'} = $columntypes[$count];
		} else {
		$cols->{'type'} = 'text';
		}
	}
$count++;
}


my $reportcolumns = encode_json(\@columns);

open (CONFIG,"../config.ini");
my @config = (<CONFIG>);
close (CONFIG);

foreach my $conf (@config) {

	if ($conf =~ /basedir = "(.*)"/) {
		$pilotpath = $1."/html/reports/report_".$timestamp.".html";
	}
	if ($conf =~ /weburl = "(.*)"/) {
		$weburl = $1."/html/reports/report_".$timestamp.".html";
	}
}


open (REPORT,"+> $pilotpath");

my $reporthtml = <<HTML;
<!DOCTYPE html>
<html>
<head>
    <title>report_$timestamp</title>
    <script src="../../libs/jquery/jquery-3.1.1.min.js" type="text/javascript"></script>
    <script src="../../libs/w2ui/w2ui-1.5.rc1.min.js" type="text/javascript"></script>
    <script src="../../libs/jquery/jquery-ui.min.js" type="text/javascript"></script>
    <link rel="stylesheet" type="text/css" href="../../libs/css/mkadvantage.css" />
    <link rel="stylesheet" type="text/css" href="../../libs/css/custom.css" />
</head>
<body>

<div id="grid" style="width: 100%; height: 700px;"></div>

<script type="text/javascript">
\$(function () {
    \$('#grid').w2grid({ 
        name: 'report_$timestamp', 
        show: { 
            toolbar: true,
            header: true,
            footer: true
        },
	onRender: function(event){
		event.onComplete = function(){
			//var reportname = 'report_$timestamp';
			//console.log(reportname);
			this.refresh();
		}
	},
	header: '$header',
        records: $records,
        method: 'GET',
        columns: $reportcolumns               
    });    
});
</script>

</body>
</html>

HTML

print REPORT $reporthtml;


#if (length($createrequest) > 0) {
#        $status = "Created";
#        $output{"$meta"}{"count"} = 1;
#} else {
#        $status = "Problem Creating Entry";
#}

$output{'status'} = $status;
$output{'reporturl'} = $weburl;

my $json = encode_json(\%output);
print $json;
